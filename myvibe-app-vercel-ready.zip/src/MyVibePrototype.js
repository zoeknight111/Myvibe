import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { motion } from "framer-motion";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";

const dummyProfiles = [
  {
    nickname: "VibeQueen",
    song: "On & On - Erykah Badu",
    moodLevel: 85,
    status: "Feeling grounded and groovy",
    isPublic: true,
    themeColor: "green",
    uploadedMedia: null,
  },
  {
    nickname: "BeatKing",
    song: "Lose Yourself - Eminem",
    moodLevel: 70,
    status: "Grinding hard today",
    isPublic: true,
    themeColor: "blue",
    uploadedMedia: null,
  },
];

export default function MyVibePrototype() {
  const [nickname, setNickname] = useState("");
  const [song, setSong] = useState("");
  const [moodLevel, setMoodLevel] = useState(50);
  const [isPublic, setIsPublic] = useState(true);
  const [themeColor, setThemeColor] = useState("blue");
  const [status, setStatus] = useState("");
  const [uploadedMedia, setUploadedMedia] = useState(null);
  const [profiles, setProfiles] = useState(dummyProfiles);
  const [topTracks, setTopTracks] = useState([]);
  const [showFeed, setShowFeed] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem("myvibe_profiles");
    if (saved) {
      setProfiles(JSON.parse(saved));
    }
  }, []);

  const handleMediaUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setUploadedMedia(URL.createObjectURL(file));
    }
  };

  const handleShare = () => {
    const newProfile = {
      nickname,
      song,
      moodLevel,
      isPublic,
      themeColor,
      status,
      uploadedMedia,
    };
    const updatedProfiles = [newProfile, ...profiles];
    setProfiles(updatedProfiles);
    localStorage.setItem("myvibe_profiles", JSON.stringify(updatedProfiles));
    setNickname("");
    setSong("");
    setStatus("");
    setMoodLevel(50);
    setUploadedMedia(null);
    setTopTracks([]);
    setShowFeed(true);
  };

  const mockSpotifyTopTracks = () => {
    setTopTracks([
      "Blinding Lights - The Weeknd",
      "Levitating - Dua Lipa",
      "Good 4 U - Olivia Rodrigo",
      "Peaches - Justin Bieber",
      "Stay - The Kid LAROI & Justin Bieber",
    ]);
  };

  return (
    <div className="min-h-screen bg-black text-white p-4">
      <h1 className="text-4xl font-bold text-center mb-8">MyVibe</h1>

      {!showFeed && (
        <Card className="max-w-md mx-auto p-4 rounded-2xl shadow-lg bg-gray-900 mb-10">
          <CardContent>
            <div className="space-y-4">
              <Input
                placeholder="Enter your nickname"
                value={nickname}
                onChange={(e) => setNickname(e.target.value)}
                className="bg-gray-800 border-gray-700 text-white"
              />
              <div className="flex space-x-2 items-center">
                <Input
                  placeholder="Your top song today"
                  value={song}
                  onChange={(e) => setSong(e.target.value)}
                  className="bg-gray-800 border-gray-700 text-white"
                />
                <Button onClick={mockSpotifyTopTracks} className="bg-green-600 hover:bg-green-500">
                  Get Top Songs
                </Button>
              </div>
              {topTracks.length > 0 && (
                <div className="bg-gray-800 p-2 rounded-lg">
                  <p className="text-sm mb-1">Choose from Spotify top tracks:</p>
                  {topTracks.map((track, idx) => (
                    <Button
                      key={idx}
                      variant="ghost"
                      className="w-full text-left justify-start hover:bg-gray-700"
                      onClick={() => setSong(track)}
                    >
                      {track}
                    </Button>
                  ))}
                </div>
              )}
              <Textarea
                placeholder="What's your vibe today?"
                value={status}
                onChange={(e) => setStatus(e.target.value)}
                className="bg-gray-800 border-gray-700 text-white"
              />
              <div>
                <label className="block mb-1">Mood Level</label>
                <Slider
                  min={0}
                  max={100}
                  step={1}
                  value={[moodLevel]}
                  onValueChange={([val]) => setMoodLevel(val)}
                />
                <p className="text-sm text-gray-400 mt-2">Mood: {moodLevel}%</p>
              </div>
              <motion.div
                className={`w-full h-10 rounded-full ${themeColor === "blue" ? "bg-blue-500" : "bg-green-500"}`}
                animate={{ width: \`\${moodLevel}%\` }}
                transition={{ duration: 0.5 }}
              />
              <div className="flex items-center justify-between">
                <span className="text-sm">Make my vibe public</span>
                <Switch checked={isPublic} onCheckedChange={setIsPublic} />
              </div>
              <div className="flex space-x-2">
                <Button
                  variant={themeColor === "blue" ? "default" : "outline"}
                  onClick={() => setThemeColor("blue")}
                >
                  Blue Theme
                </Button>
                <Button
                  variant={themeColor === "green" ? "default" : "outline"}
                  onClick={() => setThemeColor("green")}
                >
                  Green Theme
                </Button>
              </div>
              <div className="space-y-2">
                <label className="block text-sm">Upload a clip or image</label>
                <Input
                  type="file"
                  accept="image/*,video/*"
                  onChange={handleMediaUpload}
                  className="bg-gray-800 border-gray-700 text-white"
                />
                {uploadedMedia && (
                  <div className="mt-2">
                    {uploadedMedia.endsWith(".mp4") ? (
                      <video controls className="w-full rounded-lg">
                        <source src={uploadedMedia} type="video/mp4" />
                      </video>
                    ) : (
                      <img src={uploadedMedia} alt="Uploaded content" className="w-full rounded-lg" />
                    )}
                  </div>
                )}
              </div>
              <Button className="w-full bg-blue-600 hover:bg-blue-500" onClick={handleShare}>
                Share MyVibe
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="max-w-md mx-auto space-y-6">
        <h2 className="text-2xl font-semibold mb-2">Public Vibes</h2>
        {profiles.filter(p => p.isPublic).map((profile, index) => (
          <Card key={index} className="bg-gray-800 p-4 rounded-xl">
            <CardContent>
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-xl font-bold">{profile.nickname}</h3>
                <span className="text-sm italic text-gray-400">{profile.song}</span>
              </div>
              <p className="text-sm text-gray-300 mb-2">{profile.status}</p>
              <motion.div
                className={`h-3 rounded-full ${profile.themeColor === "blue" ? "bg-blue-400" : "bg-green-400"}`}
                animate={{ width: \`\${profile.moodLevel}%\` }}
                transition={{ duration: 0.5 }}
              />
            </CardContent>
          </Card>
        ))}
        <Button className="w-full mt-4 bg-gray-700 hover:bg-gray-600" onClick={() => setShowFeed(false)}>
          Create New Vibe
        </Button>
      </div>
    </div>
  );
}