# MyVibe App

This is the prototype for MyVibe — a social mood-sharing app where users can post their current vibe, mood, favorite song, and even upload media.

## 🚀 How to Run

1. Make sure you have **Node.js** and **npm** installed.
2. Unzip this folder.
3. In your terminal, navigate to the project directory and run:

```bash
npm install
npm start
```

4. Open `http://localhost:3000` in your browser to view the app.